
export interface UserRefreshTokenPayload {
    userId: string;
  }