
export interface AdminRefreshTokenPayload {
    adminId: string;
  }