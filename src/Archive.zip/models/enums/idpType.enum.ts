// src/models/enums/idpType.enum.ts

export enum IDPType {
    LOCAL='LOCAL',
    GOOGLE = 'GOOGLE',
    FACEBOOK = 'FACEBOOK',
    COGNITO = 'COGNITO',
    APPLE = 'APPLE',
    GITHUB = 'GITHUB',
  }
  