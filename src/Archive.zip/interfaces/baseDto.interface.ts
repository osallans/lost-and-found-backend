export interface BaseDTO {
    id?: string;
    created_at?: Date;
    updated_at?: Date;
    is_deleted?: boolean;
  }