export interface CountryDTO {
  code: string;
  name: string;
  nameAr?: string;
}