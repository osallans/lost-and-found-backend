export interface CityDTO {
  id?: string;
  name: string;
  nameAr?: string;
  countryCode: string;
}