// This would normally be a schema/model definition if using an ORM like TypeORM or Sequelize.
// For this in-memory example, we rely on DTOs instead.
export {};