export interface Brand {
    id: string;
    name: string;
    name_ar?: string;
    subcategory_id?: string;
    created_at: Date;
  }