import { Request, Response } from 'express';
import { AdminService } from '../services/admin.service';

import bcrypt from 'bcrypt';
import { AdminAccessTokenPayload } from '../../../auth/interfaces/adminAccessTokenPayload.interface';

export class AdminController {

}
