export interface ItemImageDTO {
  id?: string;
  itemId: string;
  imageUrl: string;
  uploadedAt?: Date;
}